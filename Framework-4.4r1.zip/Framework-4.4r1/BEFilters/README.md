BattlEye Filters
================
The BattlEye filters (.txt files) go into: <b>ARMA_3_DIR → profiles → BattlEye → missionName.mapName</b></br>
Example: <b>arma3 → profiles → BattlEye → Altis_Life.Altis</b></br></br>
<b>These BattlEye filters are a work-in-progress and are only applicable to the vanilla [Altis Life RPG] (https://github.com/ArmaLife/Altis)</b>.</br></br>
<b>Any modification</b> to the Altis Life RPG mission files will require the BattlEye filters to be updated.
